﻿namespace OneNETDataReceiver
{
    public partial class Startup
    {
        public void Configuration()
        {
        }
    }
}
